__author__ = 'nadav'
# Replace with your Facebook and Temboo credentials
FB_APP_ID = "409561189205196"
FB_APP_SECRET = "48b0486ad6776095892ae64a770b029f"
TEMBOO_ACCOUNT_NAME = "nadavgabay"
TEMBOO_APP_NAME = "myFirstApp"
TEMBOO_APP_KEY = "cb7a3ba5b2ab42ee94e3cde27eb8f2f5"
FORWARDING_URL = "http://127.0.0.1:8000/pick/profile"
#FORWARDING_URL = "http://127.0.0.1:8000/pick"
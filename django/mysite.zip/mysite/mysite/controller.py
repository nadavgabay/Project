# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from config import FB_APP_ID, FB_APP_SECRET, FORWARDING_URL
from config import TEMBOO_ACCOUNT_NAME, TEMBOO_APP_NAME, TEMBOO_APP_KEY
from temboo.Library.Facebook.OAuth import InitializeOAuth
from temboo.Library.Facebook.OAuth import FinalizeOAuth
from temboo.Library.Facebook.Reading import User
from temboo.core.session import TembooSession
import uuid
from django.template import RequestContext, loader
from facebookUtils import *
# Create a Temboo session object
from django.utils.encoding import iri_to_uri

SESSION = TembooSession(TEMBOO_ACCOUNT_NAME, TEMBOO_APP_NAME,
                        TEMBOO_APP_KEY)
CUSTOMCALLBACKID = None

STATIC_WORDS_TO_SERACH = []

def home(request):
        template = loader.get_template('templates/main.html')
        context = RequestContext(request, {
        'latest_question_list': '1',
        })
        return HttpResponse(template.render(context))


def get_login_url_to_serach_with_and(request):
    print 'get_login_url_to_serach_with_and'
    # Generate a random state token which is used as the CustomCallbackID and in the ForwardingURL
    customCallbackId = str(uuid.uuid4())

    # Instantiate the InitializeOAuth choreo to begin the OAuth process.
    initializeOAuthChoreo = InitializeOAuth(SESSION)

    # Get an InputSet object for the InitializeOAuth choreo
    initializeOAuthInputs = initializeOAuthChoreo.new_input_set()

    groups = request.GET.get('groups', '')
    useAnd = request.GET.get('and', '')
    # Set inputs for InitializeOAuth
    # Append the state token to the Forwarding URL
    initializeOAuthInputs.set_AppID(FB_APP_ID)
    initializeOAuthInputs.set_Scope("user_groups")
    CUSTOMCALLBACKID = customCallbackId
    initializeOAuthInputs.set_CustomCallbackID(customCallbackId)
    words = u"&groups=%s" % (groups)

    STATIC_WORDS_TO_SERACH.append(unicode(groups).encode('utf8'))
    print STATIC_WORDS_TO_SERACH
    initializeOAuthInputs.set_ForwardingURL(FORWARDING_URL + "?state=" + TEMBOO_ACCOUNT_NAME + "/" + customCallbackId + words+"&and="+useAnd)
    print iri_to_uri(groups)
    # Execute InitializeOAuth choreo
    initializeOAuthResults = initializeOAuthChoreo.execute_with_results(initializeOAuthInputs)
    print "~~~~The Authorization URL is: " + initializeOAuthResults.get_AuthorizationURL()

    # Redirect user to the AuthorizationURL so that they can login and grant the application access

    return HttpResponseRedirect(initializeOAuthResults.get_AuthorizationURL())

def get_user_info(request):
    print 'get_user_info'
     # Instantiate the FinalizeOAuth choreo
    finalizeOAuthChoreo = FinalizeOAuth(SESSION)

    # Get an InputSet object for the FinalizeOAuth choreo
    finalizeOAuthInputs = finalizeOAuthChoreo.new_input_set()

    # Set inputs for FinalizeOAuth
    # Get the state token parameter after the redirect to use as the CallbackID
    finalizeOAuthInputs.set_AppID(FB_APP_ID)
    finalizeOAuthInputs.set_AppSecret(FB_APP_SECRET)
    # import pdb;pdb.set_trace();
    print "~~~~The state token is: " + request.GET.get('state')
    finalizeOAuthInputs.set_CallbackID(request.GET.get('state'))

    # Execute FinalizeOAuth choreo to complete the OAuth process and retrieve an access token
    finalizeOAuthResults = finalizeOAuthChoreo.execute_with_results(finalizeOAuthInputs)

    # # Intiate the Facebook.Reading.User choreo to get the user's profile
    userChoreo = User(SESSION)

    # # Get an InputSet object for the Facebook.Reading.User choreo
    userInputs = userChoreo.new_input_set()

    # Initilize instance
    utils = facebookUtils(finalizeOAuthResults.get_AccessToken())

    listOfUserGroups = utils.getGroupsNames()


    listOfAllPosts=[]
    words_to_saerch= request.GET.get('groups', '')
    #words_to_saerch = STATIC_WORDS_TO_SERACH
    words_to_saerch = words_to_saerch.split(',')

    searchWithAndBetweenWords = request.GET.get('and', '')
    allPosts = utils.getGroupPosts(listOfUserGroups)
    #allPosts = utils.getGroupPosts(['Twitter Bootstrap Developers','יד רוחצת יד'])
    template = loader.get_template('templates/posts.html')
    context = RequestContext(request, {
        'latest_question_list': utils.parse_posts(allPosts,searchWithAndBetweenWords,words_to_saerch),
        })
    return HttpResponse(template.render(context))


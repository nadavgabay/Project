from temboo.Library.DuckDuckGo.Query import Query, QueryInputSet, QueryResultSet, QueryChoreographyExecution

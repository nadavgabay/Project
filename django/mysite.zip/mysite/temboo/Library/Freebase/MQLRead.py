# -*- coding: utf-8 -*-

###############################################################################
#
# MQLRead
# Search the Freebase dataset using the Metaweb query language (MQL).
#
# Python versions 2.6, 2.7, 3.x
#
# Copyright 2014, Temboo Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
# either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
#
#
###############################################################################

from temboo.core.choreography import Choreography
from temboo.core.choreography import InputSet
from temboo.core.choreography import ResultSet
from temboo.core.choreography import ChoreographyExecution

import json

class MQLRead(Choreography):

    def __init__(self, temboo_session):
        """
        Create a new instance of the MQLRead Choreo. A TembooSession object, containing a valid
        set of Temboo credentials, must be supplied.
        """
        super(MQLRead, self).__init__(temboo_session, '/Library/Freebase/MQLRead')


    def new_input_set(self):
        return MQLReadInputSet()

    def _make_result_set(self, result, path):
        return MQLReadResultSet(result, path)

    def _make_execution(self, session, exec_id, path):
        return MQLReadChoreographyExecution(session, exec_id, path)

class MQLReadInputSet(InputSet):
    """
    An InputSet with methods appropriate for specifying the inputs to the MQLRead
    Choreo. The InputSet object is used to specify input parameters when executing this Choreo.
    """
    def set_APIKey(self, value):
        """
        Set the value of the APIKey input for this Choreo. ((required, string) The API Key provided by Freebase.)
        """
        super(MQLReadInputSet, self)._set_input('APIKey', value)
    def set_AsOfTime(self, value):
        """
        Set the value of the AsOfTime input for this Choreo. ((optional, string) Run a query as it would have run at a specific point in time. Timestamps must be entered in the following format: 2007-01-09T22, or 2007-02.)
        """
        super(MQLReadInputSet, self)._set_input('AsOfTime', value)
    def set_Cost(self, value):
        """
        Set the value of the Cost input for this Choreo. ((optional, boolean) If cost is set to true, a key is returned in the results, indicating the computational cost incurred by lower levels of the service. Default value: false)
        """
        super(MQLReadInputSet, self)._set_input('Cost', value)
    def set_Cursor(self, value):
        """
        Set the value of the Cursor input for this Choreo. ((optional, string) If set. results can be paged.  See examples at: http://wiki.freebase.com/wiki/MQL_Read_Service)
        """
        super(MQLReadInputSet, self)._set_input('Cursor', value)
    def set_EscapeHTMLResults(self, value):
        """
        Set the value of the EscapeHTMLResults input for this Choreo. ((optional, boolean) Specify whether html results are to be escaped or not.  Default is set to: true.)
        """
        super(MQLReadInputSet, self)._set_input('EscapeHTMLResults', value)
    def set_Indent(self, value):
        """
        Set the value of the Indent input for this Choreo. ((optional, boolean) Specify whether the JSON results should be indented, or not. Enter true, or false. Default: false. Range of values: 0-10.)
        """
        super(MQLReadInputSet, self)._set_input('Indent', value)
    def set_Language(self, value):
        """
        Set the value of the Language input for this Choreo. ((optional, string) Specify the language in which the searches will be performed.  Multiple languages can be specified. Default is: /lang/en)
        """
        super(MQLReadInputSet, self)._set_input('Language', value)
    def set_Query(self, value):
        """
        Set the value of the Query input for this Choreo. ((required, string) Enter a search query  in a valid MQL JSON format.)
        """
        super(MQLReadInputSet, self)._set_input('Query', value)
    def set_UniqenessFailure(self, value):
        """
        Set the value of the UniqenessFailure input for this Choreo. ((optional, string) Specify how MQL responds to uniqueness failures. Enter hard, or soft.  Default is set to: hard.)
        """
        super(MQLReadInputSet, self)._set_input('UniqenessFailure', value)

class MQLReadResultSet(ResultSet):
    """
    A ResultSet with methods tailored to the values returned by the MQLRead Choreo.
    The ResultSet object is used to retrieve the results of a Choreo execution.
    """

    def getJSONFromString(self, str):
        return json.loads(str)

    def get_Response(self):
        """
        Retrieve the value for the "Response" output from this Choreo execution. (The response from the Freebase MQL Read API in JSON format.)
        """
        return self._output.get('Response', None)

class MQLReadChoreographyExecution(ChoreographyExecution):

    def _make_result_set(self, response, path):
        return MQLReadResultSet(response, path)

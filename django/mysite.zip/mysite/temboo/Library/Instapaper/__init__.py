from temboo.Library.Instapaper.AddURL import AddURL, AddURLInputSet, AddURLResultSet, AddURLChoreographyExecution
from temboo.Library.Instapaper.Authenticate import Authenticate, AuthenticateInputSet, AuthenticateResultSet, AuthenticateChoreographyExecution
